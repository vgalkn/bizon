<?php
//======================================================================\\
// Author: phpDolphin Russia			                                \\
// Website: http://oswall.ru									        \\
// Updated: 25/07/2013 [DD/MM/YYYY]										\\
// Language: Russian													\\
//======================================================================\\

// Character encoding
$LNG['charset'] = "utf-8";

$LNG['user_success'] = 'Пользователь успешно создан!';
$LNG['user_exists'] = 'Имя пользователя уже существует.';
$LNG['email_exists'] = 'E-Mail уже используется.';
$LNG['all_fields'] = 'Все поля обязательны для заполнения!';
$LNG['user_alnum'] = 'Имя пользователя должно быть только из букв и цифр.';
$LNG['user_too_short'] = 'Имя пользователя должно быть от 3 до 32 символов.';
$LNG['invalid_email'] = 'Формат E-Mail неверен.';
$LNG['invalid_user_pw'] = 'Неверное имя пользователя или пароль.';
$LNG['invalid_captcha'] = 'Неверный код captcha';
$LNG['log_out'] = 'Выйти';
$LNG['hello'] = 'Привет!';
$LNG['visitor'] = 'Гость';
$LNG['register'] = 'Регистрация';
$LNG['login'] = 'Войти';
$LNG['welcome_title'] = 'Добро пожаловать!';
$LNG['welcome_desc'] = 'в нашу социальную сеть';
$LNG['welcome_about'] = 'в нашей сети есть всё чтобы вы были с друзьями на связи.';
$LNG['forgot_password'] = 'Забыли пароль?';
$LNG['all_rights_reserved'] = 'Все права защищены';

// NOTIFICATION BOXES //
$LNG['settings_saved'] = 'Настройки сохранены';
$LNG['nothing_saved'] = 'Nothing Saved';
$LNG['general_settings_saved'] = 'Общие настройки успешно сохранены.';
$LNG['overall_settings_saved'] = 'Ваши настройки были успешно обновлены.';
$LNG['general_settings_unaffected'] = 'Никаких изменений не обнаружено.';
$LNG['password_changed'] = 'Пароль изменен';
$LNG['nothing_changed'] = 'Ничего не изменилось';
$LNG['password_success_changed'] = 'Пароль успешно изменен, вы можете использовать ваш новый пароль сейчас.';
$LNG['incorrect_date'] = 'Данная дата неверна. попробуйте изменить еще раз';
$LNG['password_not_changed'] = 'Ваш пароль не изменился.';
$LNG['image_saved'] = 'Изменения успешно сохранены';
$LNG['profile_picture_saved'] = 'Изображение успешно загружено и добавлено в ваш профиль.';
$LNG['error'] = 'Ошибка';
$LNG['no_file'] = 'Вы не добавили ни одного файла';
$LNG['file_exceeded'] = 'Выбранный размер файла не должен превышать <strong>%s</strong> MB.';
$LNG['file_format'] = 'Выбранный формат файла не поддерживается. разрешено только <strong>%s</strong>';
$LNG['image_removed'] = 'Изображение удалено';
$LNG['profile_picture_removed'] = 'Установленая картинка была снята';
$LNG['bio_description'] = 'Информация об вас должна быть не более %s символов';
$LNG['valid_email'] = 'Пожалуйста, введите действующий E-Mail.';
$LNG['valid_url'] = 'Пожалуйста, укажите действительный формат URL.';
$LNG['background_changed'] = 'Фон был успешно изменен.';
$LNG['background_not_changed'] = 'Фон не может быть изменен.';
$LNG['password_too_short'] = 'Пароль должен содержать не менее <strong>3</strong>-х символов.';
$LNG['something_went_wrong'] = 'Что-то пошло не так!';
$LNG['username_not_found'] = 'Мы не можем найти выбранное имя пользователя';
$LNG['userkey_not_found'] = 'Убедитесь что имя пользователя введён верно';
$LNG['password_reseted'] = 'Ваш пароль был изменен. теперь вы можете войти использую новый пароль.';
$LNG['email_sent'] = 'Письмо отправлено';
$LNG['email_reset'] = 'Письмо с инструкцией по восстановлению пароля было выслано на ваш E-Mail.';
$LNG['user_deleted'] = 'Пользователь удален';
$LNG['user_has_been_deleted'] = 'Пользователь с ID: <strong>%s</strong> был удален.';
$LNG['user_not_deleted'] = 'Выбранный пользователь (ID: %s) не может быть удален.';
$LNG['user_not_exist'] = 'Выбранный пользователь не существует.';
$LNG['theme_changed'] = 'Тема по умолчанию';
$LNG['theme_success_changed'] = 'Тема была успешно изменена.';
$LNG['theme_not_changed'] = 'К сожалению но тема не может быть изменена';
$LNG['notif_saved'] = 'Уведомления об изменениях';
$LNG['notif_success_saved'] = 'Уведомления успешно обновлены.';

// MAIL CONTENT //
$LNG['welcome_mail'] = 'Добро пожаловать в %s';
$LNG['user_created'] = 'Добро пожаловать в <strong>%s</strong><br /><br />Ваше имя пользователя: <strong>%s</strong><br />Ваш пароль: <strong>%s</strong><br /><br />Теперь вы можете войти на сайт: <a href="%s" target="_blank">%s</a>';
$LNG['recover_mail'] = 'Восстановление пароля';
$LNG['recover_content'] = 'На ваш E-Mail был отправлен запрос на восстановление пароля, если вы этого не делал просто проигнорируйте данное письмо. <br /><br />Ваше имя пользователя: <strong>%s</strong><br />Ваш ключ восстановление: <strong>%s</strong><br /><br />Вы можете восстановить пароль через ссылку: <a href="%s/index.php?a=recover&r=1" target="_blank">%s/index.php?a=recover&r=1</a>';
$LNG['ttl_comment_email'] = '%s прокомментировал ваше сообщение';
$LNG['comment_email'] = 'Привет <strong>%s</strong>,<br /><br /><strong><a href="%s">%s</a></strong> прокомментировал ваше <strong><a href="%s">сообщения.</a></strong>
<br /><br /><span style="color: #aaa;">Данное сообщения было отправлено автоматически и если вы не хотите получать рассылки от <strong>%s</strong> то вы можете сделать это по ссылке: <a href="%s">Отписаться</a>.</span>';
$LNG['ttl_like_email'] = '%s понравилось ваше сообщения';
$LNG['like_email'] = 'Привет <strong>%s</strong>,<br /><br /><strong><a href="%s">%s</a></strong> понравилось ваше <strong><a href="%s">сообщения.</a></strong>
<br /><br /><span style="color: #aaa;">Данное сообщения было отправлено автоматически и если вы не хотите получать рассылки от <strong>%s</strong> то вы можете сделать это по ссылке: <a href="%s">Отписаться</a>.</span>';

// ADMIN PANEL //

$LNG['general_link'] = 'Основное';
$LNG['security_link'] = 'Безопасность';
$LNG['manage_users'] = 'Управление пользователями';

$LNG['theme_install'] = 'Чтобы установить новую тему, загрузите её в папку <strong>themes</strong>.';
$LNG['theme_author_homepage'] = 'Открыть веб-сайт автора темы?';
$LNG['theme_version'] = 'Версия';
$LNG['theme_active'] = 'По умолчанию';
$LNG['theme_activate'] = 'Установить';
$LNG['theme_by'] = 'Автор';

// FEED //
$LNG['welcome_feed_ttl'] = 'Лента активности';
$LNG['welcome_feed'] = 'Все сообщения от ваших друзей появится на этой странице, начните с создания новых друзей.';
$LNG['welcome_timeline_ttl'] = 'Ваша лента активности';
$LNG['welcome_timeline'] = 'Все ваши сообщения будут отображаться на этой странице.';
$LNG['leave_comment'] = 'Комментировать...';
$LNG['post'] = 'Post';
$LNG['view_more_comments'] = 'Показать все комментарии';
$LNG['this_post_private'] = 'Это сообщение является приватным';
$LNG['this_post_public'] = 'Это сообщение является публичным';
$LNG['delete_this_comment'] = 'Удалить этот комментарий';
$LNG['delete_this_message'] = 'Удалить данное сообщение';
$LNG['report_this_message'] = 'Пожаловаться на сообщения';
$LNG['report_this_comment'] = 'Пожаловаться на комментарий';
$LNG['view_more_messages'] = 'Показать еще';
$LNG['food'] = 'Я поел в: <strong>%s</strong>';
$LNG['visited'] = 'Я был в:  <strong>%s</strong>';
$LNG['played'] = 'Я играл в: <strong>%s</strong>';
$LNG['watched'] = 'Я смотрел: <strong>%s</strong>';
$LNG['listened'] = 'Я слушал: <strong>%s</strong>';
$LNG['shared'] = 'Я добавил <a href="%s"><strong>сообщения</strong></a> у <a href="%s"><strong>%s</strong></a> к себе.';
$LNG['form_title'] = 'Что у вас нового?';
$LNG['comment_wrong'] = 'Что-то пошло не так, пожалуйста, обновите страницу и попробуйте еще раз.';
$LNG['comment_too_long'] = 'Извините, но максимально допустимые символы на комментарий <strong>%s</strong>.';
$LNG['comment_error'] = 'К сожалению, мы не могли разместить комментарий, пожалуйста, обновите страницу и попробуйте еще раз.';
$LNG['message_hidden'] = 'Извините, но это сообщение является приватным, только автор сообщения может видеть это.';
$LNG['message_hidden_ttl'] = 'Личное сообщение';
$LNG['login_to_lcs'] = 'Чтобы использовать все функции сайта, войдите или зарегистрируйтесь.';
$LNG['comment'] = 'Комментировать';
$LNG['share'] = 'Поделиться';
$LNG['shared_success'] = 'Сообщение успешно добавлено к вам на <a href="%s"><strong>страницу</strong></a>.';
$LNG['no_shared'] = 'Извините но мы не можем поделиться сообщением на вашу страницу, пожалуйста, обновите страницу и попробуйте еще раз';
$LNG['share_title'] = 'Поделиться сообщением';
$LNG['share_desc'] = 'Вы действительно хотите поделиться данным сообщением у себя на странице?';
$LNG['cancel'] = 'Отмена';
$LNG['close'] = 'Закрыть';

// REPORT //
$LNG['1_not_exists'] = 'Обнаружено то что сообщение удалено об котором вы хотите пожаловаться.';
$LNG['0_not_exists'] = 'Обнаружено то что комментарий удален об котором вы хотите пожаловаться.';
$LNG['1_already_reported'] = 'Спасибо! но уже сообщение было отправлено на проверку, и она будет рассмотрена в кратчайшие сроки.';
$LNG['0_already_reported'] = 'Спасибо! но уже комментарий был отправлен на проверку, и он будет рассмотрен в кратчайшие сроки.';
$LNG['1_is_safe'] = 'Внимание! администратор отклонил ваш запрос о том что сообщение имеет какой-то характер нарушающее правило нашего проекта.';
$LNG['0_is_safe'] = 'Внимание! администратор отклонил ваш запрос о том что комментарий имеет какой-то характер нарушающее правило нашего проекта.';
$LNG['1_report_added'] = 'Спасибо! данное сообщение было отправлено на проверку администрации, и она будет рассмотрена в кратчайшие сроки.';
$LNG['0_report_added'] = 'Спасибо! данный комментарий было отправлен на проверку администрации, и он будет рассмотрен в кратчайшие сроки.';
$LNG['1_report_error'] = 'Жаль, но что-то пошло не так в то время как пожаловаться об этом сообщение, пожалуйста, обновите страницу и попробуйте еще раз.';
$LNG['0_report_error'] = 'Жаль, но что-то пошло не так в то время как пожаловаться об этом мнение, пожалуйста, обновите страницу и попробуйте еще раз.';
$LNG['1_is_deleted'] = 'Сообщение было удалено, спасибо за ваши отзывы.';
$LNG['0_is_deleted'] = 'Комментарий был удален, спасибо за ваши отзывы.';

// SIDEBAR //
$LNG['filter_events'] = 'События';
$LNG['archive'] = 'Архив';
$LNG['all_events'] = 'Все события';
$LNG['sidebar_map'] = 'Места';
$LNG['sidebar_food'] = 'Питание';
$LNG['sidebar_visited'] = 'Просмотры';
$LNG['sidebar_movie'] = 'Кино';
$LNG['sidebar_game'] = 'Игры';
$LNG['sidebar_picture'] = 'Картинки';
$LNG['sidebar_video'] = 'Видео';
$LNG['sidebar_music'] = 'Музыка';
$LNG['sidebar_shared'] = 'Поделился';
$LNG['all_time'] = 'Все время';
$LNG['subscriptions'] = 'Друзья';
$LNG['subscribers'] = 'Вы в друзьях';
$LNG['welcome'] = 'Добро пожаловать';
$LNG['filter_gender'] = 'Пол';
$LNG['sidebar_male'] = 'Мужчина';
$LNG['sidebar_female'] = 'Женщина';
$LNG['all_genders'] = 'Показать всех';
$LNG['online_friends'] = 'Онлайн друзья';
$LNG['sidebar_likes'] = 'Мне понравилось';
$LNG['sidebar_comments'] = 'Комментарии';
$LNG['sidebar_messages'] = 'Сообщения';
$LNG['sidebar_chats'] = 'Чаты';
$LNG['sidebar_suggestions'] = 'Предложения друзей';
$LNG['sidebar_trending'] = 'Тенденции Темы';

// MESSAGES / CHAT //
$LNG['lonely_here'] = 'Вы не являетесь друзьями как о том если пригласить дружить?';
$LNG['write_message'] = 'Введите ваше сообщение...';
$LNG['chat_too_long'] = 'Извините, но максимально допустимых символов в сообщение чата <strong>%s</strong>.';
$LNG['blocked_by'] = 'Вы не можете отправить сообщение этому пользователю, поскольку он ограничивает круг лиц, которые могут присылать ему сообщения.';
$LNG['blocked_user'] = 'Вы не можете отправить сообщение этому пользователю, поскольку вы добавили его в черный список.';
$LNG['chat_self'] = 'Жаль, но мы не можем доставить сообщения в чат к себе.';
$LNG['chat_no_user'] = 'Ой! вы не выбрали собеседника :)';
$LNG['view_more_conversations'] = 'Показать больше сообщений';
$LNG['block'] = 'Заблокировать';
$LNG['unblock'] = 'Разблокировать';
$LNG['conversation'] = 'Диалоги';
$LNG['start_conversation'] = 'Вы можете начать разговор, выбрав из списка друзей.';
$LNG['send_message'] = 'Отправить сообщение';

// MESSAGE FORM //
$LNG['label_food'] = 'Добавить место, где вы кушали';
$LNG['label_game'] = 'Добавить игру';
$LNG['label_movie'] = 'Добавить фильм';
$LNG['label_visited'] = 'Добавить где вы осуществляли путешествия';
$LNG['label_map'] = 'Добавить местоположение';
$LNG['label_video'] = 'Добавить ссылку на видео с YouTube или Vimeo';
$LNG['label_music'] = 'Добавить музыку';
$LNG['label_image'] = 'Добавить картинку';
$LNG['message_form'] = 'Что у вас новенького?';
$LNG['file_too_big'] = 'Выбранный размер файла (%s) слишком большой, размер файла Увеличивает максимальное допустимый <strong>%s</strong>.';
$LNG['format_not_exist'] = 'Выбранный файл имеет (%s) неверный формат, пожалуйста, загрузите только <strong>%s</strong> формат изображений.';
$LNG['privacy_no_exist'] = 'Выбранная конфиденциальности не существует, пожалуйста, обновите страницу и попробуйте еще раз.';
$LNG['event_not_exist'] = 'Выбранное событие не существует, пожалуйста, обновите страницу и попробуйте еще раз.';

$LNG['unexpected_message'] = 'Неожиданная ошибка, пожалуйста, обновите страницу и попробуйте еще раз.';
$LNG['message_too_long'] = 'Извините, но максимально допустимых символов в сообщение <strong>%s</strong>.';
$LNG['files_selected'] = 'выбрано изображений';
$LNG['too_many_images'] = 'Максимальное количество изображений, допустимых к загрузке на сообщение <strong>%s</strong>, вы попытались загрузить <strong>%s</strong> картинок.';

// USER PANEL //
$LNG['user_menu_general'] = 'Общие настройки';
$LNG['user_menu_security'] = 'Пароль';
$LNG['user_menu_avatar'] = 'Настройка профиля';
$LNG['user_menu_notifications'] = 'Уведомление';

$LNG['user_ttl_general'] = 'Общие настройки';
$LNG['user_ttl_security'] = 'Настройка пароля';
$LNG['user_ttl_avatar'] = 'Настройка профиля';
$LNG['user_ttl_notifications'] = 'Уведомление';

$LNG['user_desc_general'] = 'Общие настройка вашего аккаунта.';
$LNG['user_desc_security'] = 'Изменение своего пароля.';
$LNG['user_desc_avatar'] = 'Настройка аватара';
$LNG['user_desc_cover'] = 'Настройка обложки профиля';
$LNG['user_desc_notifications'] = 'Изменить настройки уведомлений.';

$LNG['ttl_background'] = 'Фон';
$LNG['sub_background'] = 'Выберите фон для вашего профиля.';

$LNG['ttl_first_name'] = 'Имя';
$LNG['sub_first_name'] = 'Введите ваше имя.';

$LNG['ttl_last_name'] = 'Фамилия';
$LNG['sub_last_name'] = 'Введите свою фамилию.';

$LNG['ttl_email'] = 'E-Mail';
$LNG['sub_email'] = 'E-Mail не будет отображаться.';

$LNG['ttl_location'] = 'Город';
$LNG['sub_location'] = 'Где вы живете?';

$LNG['ttl_website'] = 'Веб-сайт';
$LNG['sub_website'] = 'Если у вас есть блог, личная страница, введите его.';

$LNG['ttl_gender'] = 'Пол';
$LNG['sub_gender'] = 'Выберите пол (мужской или женский).';

$LNG['ttl_profile'] = 'Профиль';
$LNG['sub_profile'] = 'Приватность профиля.';

$LNG['ttl_messages'] = 'Сообщения';
$LNG['sub_messages'] = 'Приватность сообщений.';

$LNG['ttl_offline'] = 'Ваш статус';
$LNG['sub_offline'] = 'Видимость статуса в диалоге';

$LNG['ttl_facebook'] = 'Facebook';
$LNG['sub_facebook'] = 'Ваш адрес профиля на Facebook.';

$LNG['ttl_twitter'] = 'Twitter';
$LNG['sub_twitter'] = 'Ваш адрес профиля в Twitter.';

$LNG['ttl_google'] = 'Google+';
$LNG['sub_google'] = 'Ваш адрес профиля на Google+.';

$LNG['ttl_bio'] = 'О себе';
$LNG['sub_bio'] = 'Информация об вас (160 символов).';

$LNG['ttl_born'] = 'День рождения';
$LNG['sub_born'] = 'Выберите дату вашего рождения (день, месяц, год)';

$LNG['ttl_not_verified'] = 'Не проверен';
$LNG['ttl_verified'] = 'Проверен';
$LNG['sub_verified'] = 'Проверенный значок на профиль пользователя';

$LNG['ttl_upload_avatar'] = 'Добавить выбранное изображение профиля.';
$LNG['ttl_delete_avatar'] = 'Удалите текущее изображение профиля.';

$LNG['opt_public'] = 'Публичный';
$LNG['opt_private'] = 'Приватный';
$LNG['opt_semi_private'] = 'Только подписанным разрешено';

$LNG['opt_offline_off'] = 'Онлайн';
$LNG['opt_offline_on'] = 'Оффлайн';

$LNG['no_gender'] = 'Без пола';
$LNG['male'] = 'Мужчина';
$LNG['female'] = 'Женщина';

$LNG['ttl_upload'] = 'Загрузить';
$LNG['ttl_password'] = 'Пароль';
$LNG['sub_password'] = 'Введите новый пароль (не менее 3 символов).';
$LNG['save_changes'] = 'Сохранить изменения';
$LNG['ttl_upload_photo'] = 'Загрузить изображение';
$LNG['ttl_upload_cover'] = 'Загрузить обложку';
$LNG['ttl_delete_photo'] = 'Удалить картинку';

$LNG['ttl_notificationl'] = 'Мне нравиться';
$LNG['sub_notificationl'] = 'Выводить предупреждения и уведомления об <strong>Мне нравиться</strong>';

$LNG['ttl_notificationc'] = 'Комментарии';
$LNG['sub_notificationc'] = 'Выводить предупреждения и уведомления об новых <strong>Комментариев</strong>';

$LNG['ttl_notificationm'] = 'Сообщения';
$LNG['sub_notificationm'] = 'Выводить предупреждения и уведомления об новых <strong>Сообщениях</strong>';

$LNG['ttl_notificationd'] = 'Диалоги';
$LNG['sub_notificationd'] = 'Выводить предупреждения и уведомления об новых <strong>Диалогов</strong>';

$LNG['ttl_email_comment'] = 'Комментарии по E-Mail';
$LNG['sub_email_comment'] = 'Получать на E-Mail, когда кто-то комментарии на ваши сообщения.';

$LNG['ttl_email_like'] = 'Мне нравиться по E-Mail';
$LNG['sub_email_like'] = 'Получать на E-Mail, когда кому-то нравиться ваши сообщения.';

$LNG['user_ttl_sidebar'] = 'Настройки';

// ADMIN PANEL //
$LNG['admin_login'] = 'Авторизация в админ-панеле';
$LNG['admin_user_name'] = 'Логин';
$LNG['desc_admin_user'] = 'Ваш логин';
$LNG['admin_pass'] = 'Пароль';
$LNG['desc_admin_pass'] = 'Ваш пароль';
$LNG['admin_menu_general'] = 'Общие настройки';
$LNG['admin_menu_security'] = 'Пароль';
$LNG['admin_menu_users'] = 'Управление пользователями';
$LNG['admin_menu_logout'] = 'Выйти';
$LNG['admin_menu_stats'] = 'Статистика';
$LNG['admin_menu_users_settings'] = 'Настройка пользователей';
$LNG['admin_menu_themes'] = 'Темы';
$LNG['admin_menu_manage_reports'] = 'Жалобы от пользователей';
$LNG['admin_menu_manage_ads'] = 'Рекламный менеджер';

$LNG['admin_ttl_sidebar'] = 'Меню';
$LNG['admin_ttl_general'] = 'Общие настройки';
$LNG['admin_ttl_security'] = 'Пароль';
$LNG['admin_ttl_themes'] = 'Темы';
$LNG['admin_ttl_users'] = 'Управление пользователями';
$LNG['admin_ttl_stats'] = 'Статистика';
$LNG['admin_ttl_users_settings'] = 'Настройка пользователей';
$LNG['admin_ttl_manage_reports'] = 'Жалобы от пользователей';
$LNG['admin_ttl_manage_ads'] = 'Рекламный менеджер';

$LNG['admin_desc_general'] = 'Изменить общие параметры сайта.';
$LNG['admin_desc_users_settings'] = 'Изменить общие параметры пользователей.';
$LNG['admin_desc_themes']  = 'Изменить интерфейс веб-сайта.';
$LNG['admin_desc_security'] = 'Измените пароль администратора.';
$LNG['admin_desc_users'] = 'Управление зарегистрированным пользователям.';
$LNG['admin_desc_stats'] = 'Пользователи и статистики сайта';
$LNG['admin_desc_edit_users'] = 'Редактировать настройки пользователя';
$LNG['admin_desc_manage_reports'] = 'Управление жалобами на сообщения и комментарии.';
$LNG['admin_desc_manage_ads'] = 'Рекламный менеджер';

$LNG['admin_ttl_title'] = 'Название';
$LNG['admin_sub_title'] = 'Название вашего сайта';

$LNG['admin_ttl_captcha'] = 'Каптча';
$LNG['admin_sub_captcha'] = 'Использовать CAPTCHA при регистрации';

$LNG['admin_ttl_timestamp'] = 'Отметка времени';
$LNG['admin_sub_timestamp'] = 'Сообщения, комментарии и диалоги тип метки';

$LNG['admin_ttl_msg_perpage'] = 'Сообщения';
$LNG['admin_sub_msg_perpage'] = 'Количество сообщений на странице';

$LNG['admin_ttl_com_perpage'] = 'Комментарии';
$LNG['admin_sub_com_perpage'] = 'Количество комментариев на сообщение';

$LNG['admin_ttl_chat_perpage'] = 'Диалоги';
$LNG['admin_sub_chat_perpage'] = 'Количество чата на странице';

$LNG['admin_ttl_smiles'] = 'Смайлы';
$LNG['admin_sub_smiles'] = 'Разрешить и трансформировать на короткие сообщения, комментарии и общение в смайлики';

$LNG['admin_ttl_nperpage'] = 'Уведомление';
$LNG['admin_sub_nperpage'] = 'Количество уведомлений, которые будут показаны (по странице)';

$LNG['admin_ttl_qperpage'] = 'Поиск';
$LNG['admin_sub_qperpage'] = 'Количество пользовательских результатов на страницу (Search Page)';

$LNG['admin_ttl_msg_limit'] = 'Лимит сообщениев';
$LNG['admin_sub_msg_limit'] = 'Максимально допустимое количество символов в сообщение';

$LNG['admin_ttl_chat_limit'] = 'Лимит диалогов';
$LNG['admin_sub_chat_limit'] = 'Максимально допустимое количество символов в диалогах';

$LNG['admin_ttl_email_user'] = 'Потверждение E-Mail';
$LNG['admin_sub_email_user'] = 'Потверждение аккаунта при регистрации по E-Mail';

$LNG['admin_ttl_notificationsm'] = 'Уведомление об сообщение';
$LNG['admin_sub_notificationsm'] = 'Интервал обновления для проверки наличия новых сообщений';

$LNG['admin_ttl_notificationsn'] = 'Уведомление об событиях';
$LNG['admin_sub_notificationsn'] = 'Интервал обновления для проверки новых уведомлений события';

$LNG['admin_ttl_chatrefresh'] = 'Обновление диалогов';
$LNG['admin_sub_chatrefresh'] = 'Время, как часто обновления окна диалогов с новыми сообщениями';

$LNG['admin_ttl_timeonline'] = 'Онлайн пользователи';
$LNG['admin_sub_timeonline'] = 'Количество времени, чтобы считаться онлайн с деятельностью последнего пользователя';

$LNG['admin_ttl_image_profile'] = 'Размер изображения (Профиль)';
$LNG['admin_sub_image_profile'] = 'Размер изображения разрешено загружать (декоративный профиль и аватар)';

$LNG['admin_ttl_image_format'] = 'Формат изображения (Профиль)';
$LNG['admin_sub_image_format'] = 'Формат изображения позволили Загрузить (декоративный профиль и аватар), используйте только GIF, PNG, JPG другие форматы не поддерживаются';

$LNG['admin_ttl_message_image'] = 'Размер изображения (сообщений)';
$LNG['admin_sub_message_image'] = 'Размер изображения разрешено загружать (сообщений)';

$LNG['admin_ttl_message_format'] = 'Формат изображения (сообщений)';
$LNG['admin_sub_message_format'] = 'Формат изображения позволили Загрузить (сообщений), используйте только GIF, PNG, JPG другие форматы не поддерживаются';

$LNG['admin_ttl_censor'] = 'Цензура';
$LNG['admin_sub_censor'] = 'Слова подвергаться цензуре (деленное на \',\' [comma])';

$LNG['admin_ttl_ad1'] = 'Рекламный блок 1';
$LNG['admin_sub_ad1'] = 'Рекламный блок 1 (нижняя страницы приветствия)';

$LNG['admin_ttl_ad2'] = 'Рекламный блок 2';
$LNG['admin_sub_ad2'] = 'Рекламный блок 2 (Sidebar [Личная страница активности])';

$LNG['admin_ttl_ad3'] = 'Рекламный блок 3';
$LNG['admin_sub_ad3'] = 'Рекламный блок  3 (Sidebar [Лента активности])';

$LNG['admin_ttl_ad4'] = 'Рекламный блок  4';
$LNG['admin_sub_ad4'] = 'Рекламный блок  4 (Sidebar [Профиль])';

$LNG['admin_ttl_ad5'] = 'Рекламный блок  5';
$LNG['admin_sub_ad5'] = 'Рекламный блок  5 (Sidebar [отдельные сообщения])';

$LNG['admin_ttl_ad6'] = 'Рекламный блок 6';
$LNG['admin_sub_ad6'] = 'Рекламный блок 6 (Sidebar [страница поиска людей])';

$LNG['admin_ttl_password'] = 'Пароль';
$LNG['admin_sub_password'] = 'Оставьте его в таком виде, если вы не хотите изменить его';

$LNG['admin_ttl_edit'] = 'Редактировать';
$LNG['admin_ttl_edit_profile'] = 'Редактировать профиль';

$LNG['admin_ttl_delete'] = 'Удалить';
$LNG['admin_ttl_delete_profile'] = 'Удалить профиль';

$LNG['admin_ttl_mail'] = 'Email';
$LNG['admin_ttl_username'] = 'Имя пользователя';
$LNG['admin_ttl_id'] = 'ID'; // As in user ID

$LNG['admin_ttl_mprivacy'] = 'Приватность сообщений';
$LNG['admin_sub_mprivacy'] = 'Пользователь приватности сообщений по умолчанию (пользователь может в настройках изменить)';

$LNG['admin_ttl_notificationl'] = 'Мне нравиться';
$LNG['admin_sub_notificationl'] = 'Выводить предупреждения и уведомления об <strong>Мне нравиться</strong> (пользователь может в настройках изменить)';

$LNG['admin_ttl_notificationc'] = 'Комментарии';
$LNG['admin_sub_notificationc'] = 'Выводить предупреждения и уведомления об новых <strong>Комментариев</strong> (пользователь может в настройках изменить)';

$LNG['admin_ttl_notificationm'] = 'Сообщения';
$LNG['admin_sub_notificationm'] = 'Выводить предупреждения и уведомления об новых <strong>Сообщениях</strong> (пользователь может в настройках изменить)';

$LNG['admin_ttl_notificationd'] = 'Диалоги';
$LNG['admin_sub_notificationd'] = 'Выводить предупреждения и уведомления об новых <strong>Диалогов</strong> (пользователь может в настройках изменить)';

$LNG['admin_ttl_email_comment'] = 'Комментарии по E-Mail';
$LNG['admin_sub_email_comment'] = 'Включить отправку сообщений на E-Mail, когда кто-то прокоментировал сообщение.';

$LNG['admin_ttl_email_like'] = 'Мне нравиться по E-Mail';
$LNG['admin_sub_email_like'] = 'Включить отправку сообщений на E-Mail, когда кому-то нравиться .';

$LNG['admin_ttl_ilimit'] = 'Максимум изображения';
$LNG['admin_sub_ilimit'] = 'Максимальная изображений допустимых к загрузке за сообщение';

$LNG['admin_ttl_wholiked'] = 'Кому понравилось';
$LNG['admin_sub_wholiked'] = 'Количество аватары, которые будут показаны возле записи.';

$LNG['admin_ttl_rperpage'] = 'Жалобы';
$LNG['admin_sub_rperpage'] = 'Жалобы на странице (Управление отчетами)';

$LNG['admin_ttl_sperpage'] = 'Друзья';
$LNG['admin_sub_sperpage'] = 'Количество друзей на странице будет отображаться (страницы профиля)';

$LNG['admin_ttl_ronline'] = 'Онлайн друзья';
$LNG['admin_sub_ronline'] = 'Количество друзей онлайн, которые будут отображаться в ленте активности / профиль (боковая панель).';

$LNG['admin_ttl_nperwidget'] = 'Выпадающее Уведомления';
$LNG['admin_sub_nperwidget'] = 'Количество уведомлений, которые будут показаны в категории (мне нравиться, комментарии, сообщения)';

$LNG['admin_ttl_uperpage'] = 'Пользователи';
$LNG['admin_sub_uperpage'] = 'Число пользователей на страницу (Управление пользователями)';

$LNG['admin_sub_verified'] = 'Проверенный профиль пользователя по умолчанию? (Не рекомендуется)';

$LNG['per_page'] = '/ страница';
$LNG['second'] = 'секунда';
$LNG['seconds'] = 'секунды';
$LNG['minute'] = 'минута';
$LNG['minutes'] = 'минут';
$LNG['hour'] = 'час';
$LNG['recommended'] = 'рекомендованный';
$LNG['edit_user'] = 'Поиск';
$LNG['username_to_edit'] = 'Введите имя пользователя';
$LNG['username_to_edit_sub'] = 'Введите имя пользователя которого хотите изменить';

// STATS //
$LNG['user_registration'] = 'Регистрация пользователя';
$LNG['users_today'] = 'Сегодня';
$LNG['users_this_month'] = 'В этом месяце';
$LNG['users_last_30'] = 'Последние 30 дней';
$LNG['total_users'] = 'Всего';

$LNG['messages_and_comments'] = 'Сообщения и комментарии';
$LNG['reports_title'] = 'Жалобы - (Сообщения %26 Комментарии)';
$LNG['total_messages'] = 'Всего сообщений';
$LNG['public_messages'] = 'Публичное сообщения';
$LNG['private_messages'] = 'Приватное сообщения';
$LNG['total_comments'] = 'Всего комментариев';
$LNG['stats_total'] = 'Всего';
$LNG['stats_public'] = 'Публичное';
$LNG['stats_private'] = 'Приватное';
$LNG['stats_reports'] = 'Жалобы';
$LNG['total_reports'] = 'Всего жалоб';
$LNG['pending_reports'] = 'В ожидании жалоб';
$LNG['safe_reports'] = 'Безопасные жалобы';
$LNG['deleted_reports'] = 'Удалить жалобу';
$LNG['likes_today'] = 'Лайков сегодня';
$LNG['likes_this_month'] = 'Лайков за месяц';
$LNG['likes_last_30'] = 'Последние 30 дней';
$LNG['likes_total'] = 'Всего лайков';
$LNG['likes'] = 'Мне нравиться';

// MANAGE REPORTS //
$LNG['admin_reports_id'] = 'ID';
$LNG['admin_reports_view'] = 'Открыть запись';
$LNG['admin_reports_type'] = 'Тип';
$LNG['admin_reports_by'] = 'Пожаловался';
$LNG['admin_reports_safe'] = 'Принять';
$LNG['admin_reports_delete'] = 'Удалить';
$LNG['admin_reports_ttl_safe'] = 'Отменить';

// LIKES //
$LNG['already_liked'] = 'Вам нравиться это сообщение';
$LNG['already_disliked'] = 'Вам не нравиться это сообщение';
$LNG['like'] = 'Мне нравиться';
$LNG['dislike'] = 'Мне не нравиться';
$LNG['like_message_not_exist'] = 'Это сообщение несуществует или была удалена.';
$LNG['liked_this'] = 'это понравилось';

// MISC //
$LNG['sponsored'] = 'Спонсоры';
$LNG['censored'] = '<strong>цензуре</strong>';
$LNG['new_like_notification'] = '<strong><a href="%s">%s</a></strong> понравилось <strong><a href="%s">сообщение</a></strong>';
$LNG['new_comment_notification'] = '<strong><a href="%s">%s</a></strong> прокоментировал <strong><a href="%s">сообщение</a></strong>';
$LNG['new_message_notification'] = '<strong><a href="%s">%s</a></strong> опубликовал новое <strong><a href="%s">сообщение</a></strong>';
$LNG['new_chat_notification'] = '<strong><a href="%s">%s</a></strong> отправил вам в диалоге <strong><a href="%s">сообщение</a></strong>';
$LNG['change_password'] = 'Изменить пароль';
$LNG['enter_new_password'] = 'Введите новый пароль';
$LNG['enter_reset_key'] = 'Введите код активации';
$LNG['enter_username'] = 'Введите имя пользователя';
$LNG['reset_key'] = 'Код активации';
$LNG['new_password'] = 'Новый пароль';
$LNG['password_recovery'] = 'Восстановление пароля';
$LNG['password'] = 'Пароль';
$LNG['recover']	= 'Восстановление';
$LNG['recover_sub_username'] = 'Введите имя пользователя который хотите восстановить пароль.';
// PROFILE //
$LNG['profile_not_exist'] = 'Просим прощения, но профиль не существует.';
$LNG['profile_semi_private'] = 'Извините, но является приватным, только друзья этого пользователь может просмотреть профиль.';
$LNG['profile_private'] = 'Извините, но этот профиль является приватным.';
$LNG['profile_not_exist_ttl'] = 'Профиль не существует.';
$LNG['profile_semi_private_ttl'] = 'Профиль является приватным.';
$LNG['profile_private_ttl'] = 'Профиль является приватным.';
$LNG['add_friend'] = 'Добавить в друзья';
$LNG['remove_friend'] = 'Удалить из друзей';
$LNG['profile_about'] = 'Информация';
$LNG['profile_born'] = 'Родился';
$LNG['profile_location'] = 'Проживание';
$LNG['profile_website'] = 'Веб-сайт';
$LNG['profile_view_site'] = '(посетить)';
$LNG['profile_view_profile'] = 'Показать профиль';
$LNG['profile_bio']	= 'О себе';
$LNG['new_messages_posted'] = 'Есть новое сообщения (нажмите сюда чтобы показать).';
$LNG['verified_user'] = 'Официальный профиль';
$LNG['edit_profile_cover'] = 'Изменение профиля изображения';
$LNG['view_all_notifications'] = 'Показать все уведомления';
$LNG['close_notifications'] = 'Закрыть';
$LNG['notifications_settings'] = 'Настройка уведомлений';
$LNG['no_notifications'] = 'Для вас нет новых уведомлений :(';
$LNG['search_title'] = 'Результат поиска';
$LNG['view_all_results'] = 'Показать все результаты';
$LNG['close_results'] = 'Закрыть результаты';
$LNG['no_results'] = 'Введёные вами данные не были найдены';
$LNG['no_results_ttl'] = 'Результат поиска';

// GENERAL //
$LNG['title_profile'] = 'Профиль';
$LNG['title_feed'] = 'Лента активности';
$LNG['title_post'] = 'Пост';
$LNG['title_messages'] = 'Сообщение';
$LNG['title_settings'] = 'Настройки';
$LNG['title_timeline'] = 'Ваша лента';
$LNG['title_notifications'] = 'Уведомление';
$LNG['title_admin']	= 'Админка';
$LNG['on'] = 'Включен';
$LNG['off'] = 'Выключен';
$LNG['none'] = 'Нет';
$LNG['pages'] = 'Страница';
$LNG['search_for_people'] = 'поиск людей, хештегов';
$LNG['new_message'] = 'Новое сообщение';
$LNG['privacy_policy'] = 'Политика конфиденциальности';
$LNG['terms_of_use'] = 'Правила использования';
$LNG['about'] = 'О нас';
$LNG['disclaimer'] = 'Отказ от отвественности';
$LNG['contact'] = 'Обратная связь';
$LNG['api_documentation'] = 'API Документация';
$LNG['developers'] = 'Разработчикам';
$LNG['language'] = 'Язык';
?>