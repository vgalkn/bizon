<?php
// Theme Name
$name = 'Dolphin Russia';

// Theme Author
$author = 'Pricop Alexandru - Mihai & SibWeb Group';

// Theme URL
$url = 'http://www.phpdolphin.com/';

// Theme Version
$version = '1.1.2';
?>
